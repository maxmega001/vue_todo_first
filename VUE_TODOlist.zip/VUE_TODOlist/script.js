const app = new Vue({
    el: "#app",
    data: {
        form: {
            task: '',
            deadline: new Date(),
            renameTask: '',
        },
        message: new Date(),
        arra: [], 
    },
    // computed: {
        // message_2(){
        //     return this.message + 1
        // },
        // changeDate(){
        //     let arra2 = [];
        //     this.arra.forEach(element => {
        //         arra2.push({
        //             id: element.id,
        //             task: element.task,
        //             date: new Date(element.date.substr(8,2)+'/'+element.date.substr(5,2)+'/'+element.date.substr(0,4)),
        //         })
        //     });
        //     return arra2;
        // }x
    // },
    // mounted(){
        // console.log(this.message_2);
    // },
    methods: {
        show_model(){
            console.log(this.form.task);
        },
        addTask(){
            console.log('YO'+this.form.deadline);
            this.arra.push({
                id: this.arra.length,
                task: this.form.task,
                date: new Date(this.form.deadline.substr(5,2)+'/'+this.form.deadline.substr(8,2)+'/'+this.form.deadline.substr(0,4)),
                done: 'В работе',
                isRename: true,
            })
            this.form.task = '';
        },
        deleteTask(id){
            this.arra.splice(id, 1);
        },
        doneTask(id){
            if(this.arra[id].done == 'В работе'){
                this.arra[id].done = 'Готово';
            } else{
                this.arra[id].done = 'В работе';
            }
        },
        editTask(id){
            if(this.arra[id].isRename == false){
                if (this.form.renameTask != ''){
                    this.arra[id].task = this.form.renameTask;
                    this.form.renameTask = '';
                }
                this.arra[id].isRename = true;
            }else{
                this.arra[id].isRename = false;
            }
        },
    }
})